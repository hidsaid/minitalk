#include "minitalk.h"

int	flag = 0;

void	handler(int sig)
{
	(void)sig;
	flag = 1;
}

void	send_string(int pid_server, char *str)
{
	int	i;
	int	j;

	i = 0;
	while (str[i])
	{
		j = 0;
		while (j < 8)
		{
			if (((str[i] >> j) & 1) == 0)
				kill(pid_server, SIGUSR1);
			else
				kill(pid_server, SIGUSR2);
			// usleep(500);
			while (flag == 0)
				;
			flag = 0;
			j++;
		}
		i++;
	}
}

int	main(int argc, char **argv)
{
	signal(SIGUSR1, handler);
	if (argc != 3)
		return (0);
	int pid_server = ft_atoi(argv[1]);
	send_string(pid_server, argv[2]);
	return (0);
}